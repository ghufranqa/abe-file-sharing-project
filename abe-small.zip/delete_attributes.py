from app1 import app, db, Attribute, UserAttribute

with app.app_context():
    print("=== Before Delete ===")
    all_attrs = Attribute.query.all()
    print(f"عدد الـ Attributes: {len(all_attrs)}")
    
    # حذف كل الـ attributes اللي اسمها فيها test
    deleted_attrs = Attribute.query.filter(
        Attribute.name.like('%test%')
    ).delete()
    
    # أو حذف attributes معينة بالـ ID
    # Attribute.query.filter(Attribute.id.in_([1,2,3])).delete()
    
    db.session.commit()
    print(f"Done {deleted_attrs} attribute")
    
    print("=== after delete  ===")
    remaining = Attribute.query.all()
    for attr in remaining:
        print(f"- {attr.id}: {attr.name}")

