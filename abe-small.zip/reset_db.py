from app1 import app, db
import os

# Delete old database
if os.path.exists('app.db'):
    os.remove('app.db')
    print("Old app.db deleted")

with app.app_context():
    db.create_all()
    print("✅ New database created with email field!")

