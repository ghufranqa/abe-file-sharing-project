from app1 import app, db, User



with app.app_context():

    count = User.query.filter(User.username.like('%فثسف%')).delete()

    db.session.commit()

    print(f"تم حذف {count} مستخدمين")
