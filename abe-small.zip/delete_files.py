from app1 import app, db, File

with app.app_context():
    deleted = File.query.delete()
    db.session.commit()
    print(f"Deleted {deleted} files")
    
    import os
    import glob
    for f in glob.glob("uploads/*"):
        os.remove(f)
    print("uploads/ folder cleared")

